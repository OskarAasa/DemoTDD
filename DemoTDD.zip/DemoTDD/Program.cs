﻿// See https://aka.ms/new-console-template for more information
using DemoTDD;

Console.WriteLine("Hello, World!");
VerifyPersonNr verfifyPersonNr = new();
verfifyPersonNr.ValidPersonNr("19 901229-2935");